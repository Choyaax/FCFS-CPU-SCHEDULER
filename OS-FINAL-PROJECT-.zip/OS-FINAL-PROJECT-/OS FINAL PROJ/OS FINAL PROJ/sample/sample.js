class Process {
    constructor(pid, arrivalTime, burstTime) {
        this.pid = pid;
        this.arrivalTime = arrivalTime;
        this.burstTime = burstTime;
    }
}

function fcfsScheduling(processes) {
    processes.sort((a, b) => a.arrivalTime - b.arrivalTime);

    let currentTime = 0;
    let waitingTime = 0;

    console.log("FCFS Scheduling:");
    processes.forEach(process => {
        if (currentTime < process.arrivalTime) {
            currentTime = process.arrivalTime;
        }
        console.log(`Process ${process.pid}: Start Time: ${currentTime}, End Time: ${currentTime + process.burstTime}`);
        waitingTime += currentTime - process.arrivalTime;
        currentTime += process.burstTime;
    });

    const averageWaitingTime = waitingTime / processes.length;
    console.log(`Average Waiting Time: ${averageWaitingTime}`);
}

// Example usage
const processes = [
    new Process(1, 0, 5),
    new Process(2, 1, 3),
    new Process(3, 2, 8),
    new Process(4, 3, 6)
];

fcfsScheduling(processes);
    class Process {
        constructor(pid, arrivalTime, burstTime) {
            this.pid = pid;  //number of processes na gi add as a user 
            this.arrivalTime = arrivalTime;  ///user setted 
            this.burstTime = burstTime;   //kani pod
            this.completionTime = 0 ;
            this.turnAroundTime = 0 ; 
            this.waitingTime = 0; 
        }
    }

    function fcfsScheduling(processes) {
        processes.sort((a, b) => a.arrivalTime - b.arrivalTime);

        let currentTime = 0;  //set the variables kay gamit siya like oh yeah 
        let totalWaitingTime = 0;
        let totalCompletionTime = 0; 
        let totalTurnAroundTime = 0; 
        let ganttChartHTML = '';
        processes.forEach(process => {
            if (currentTime < process.arrivalTime) {
                currentTime = process.arrivalTime;
            }
            process.completionTime = currentTime + process.burstTime;
            process.turnAroundTime = process.completionTime - process.arrivalTime;
            process.waitingTime = currentTime - process.arrivalTime;
        
            ganttChartHTML += `
            <tr>
            <td>P${process.pid}</td>
            <td>${currentTime}</td>
            <td>${process.burstTime}</td>
            </tr>
            `;
            currentTime += process.burstTime;
            totalWaitingTime += process.waitingTime;
            totalTurnAroundTime += process.turnAroundTime; 
            totalCompletionTime += process.completionTime; 
        }); 

        const averageWaitingTime = totalWaitingTime / processes.length;
        const turnAroundTime = totalTurnAroundTime / processes.length; 
        const completionTime = totalCompletionTime / processes.length;
        document.getElementById('requiredTime').value = currentTime;
    
        const tableBody = document.querySelector('#processTable');
        tableBody.innerHTML = `
        <thead>
        <tr>
        <th> Process Time </th>
        <th>Arrival Time</th>
        <th>Burst Time</th>
        <th>Completion Time</th>
        <th>Turn Around Time</th>
        <th>Waiting Time</th>
    </tr>
    </thead>
    <tbody>
    ${processes.map(process =>`
    <tr>
    <td>P${process.pid}</td>
    <td>${process.arrivalTime}</td>
    <td>${process.burstTime}</td>
    <td>${process.completionTime}</td>
    <td>${process.turnAroundTime}</td>
    <td>${process.waitingTime}</td>
    </tr>
    `).join('')}
 <tr>
   <div class = "row align-items-start">
 <td >Average Turn Around Time: ${turnAroundTime.toFixed(2)}</td> 

 <td colspan ="3" style ="text-align:left;"> Average Completion Time:${completionTime.toFixed(2)}</td>
   <td colspan = "6" style ="text-align:right;">Average Waiting Time: ${averageWaitingTime.toFixed(2)}</td> 

    </tr>
    </tbody>
        `;
    }

    function generateTable() {
        const numProcesses = parseInt(document.getElementById('numProcesses').value);
        const tableBody = document.querySelector('#processTable tbody');
        tableBody.innerHTML = '';

        for (let i = 1; i <= numProcesses; i++) {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>P${i}</td>
                <td><input type="number" id="arrivalTime${i}" value="0"></td>
                <td><input type="number" id="burstTime${i}" value="1"></td>
                <td></td>
                <td></td>
                <td></td>
            `;
            tableBody.appendChild(row);
        }
    }

    function performScheduling() {
        const numProcesses = parseInt(document.getElementById('numProcesses').value);
        const processes = [];

        for (let i = 1; i <= numProcesses; i++) {
            const arrivalTime = parseInt(document.getElementById(`arrivalTime${i}`).value);
            const burstTime = parseInt(document.getElementById(`burstTime${i}`).value);
            processes.push(new Process(i, arrivalTime, burstTime));
        }

        fcfsScheduling(processes);
        updateGanttChart(processes);
    } 

    // Update Gantt chart
    document.getElementById('ganttChart').innerHTML = ganttChartHTML; //to be continued 

    function requiredTime(){
 
    if(newrequiredTime !== null){
    document.getElementById('requiredTimeInput'); 
    }
    }     //mogawas after performing FCFS scheduling 



    function updateGanttChart(processes) {
        processes.sort((a, b) => a.arrivalTime - b.arrivalTime);
    
        let currentTime = 0;
        let ganttChartHTML = '<tr><th>Process</th><th>Start Time</th><th>End Time</th></tr>';
    
        processes.forEach(process => {
            if (currentTime < process.arrivalTime) {
                currentTime = process.arrivalTime;
            }
            const endTime = currentTime + process.burstTime;
    
            ganttChartHTML += ` 
               <tr>
                <td>P${process.pid}</td> 
                <td>${currentTime}</td> 
                <td>${endTime}</td> 
            </tr> 
            `;
            currentTime = endTime;
        });
    
        document.getElementById('ganttChart').innerHTML = ganttChartHTML;
    }
    

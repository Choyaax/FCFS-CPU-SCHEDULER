class Process {
    constructor(pid, arrivalTime, burstTime) {
        this.pid = pid;  //number of processes na gi add as a user 
        this.arrivalTime = arrivalTime;  ///user setted 
        this.burstTime = burstTime;   //kani pod
        this.completionTime = 0 ;
        this.turnAroundTime = 0 ; 
        this.waitingTime = 0; 
    }
}

function fcfsScheduling(processes) {
    processes.sort((a, b) => a.arrivalTime - b.arrivalTime);

    let currentTime = 0;
    let totalWaitingTime = 0;

    processes.forEach(process => {
        if (currentTime < process.arrivalTime) {
            currentTime = process.arrivalTime;
        }
        process.completionTime = currentTime + process.burstTime;
        process.turnAroundTime = process.completionTime - process.arrivalTime;
        process.waitingTime = currentTime - process.arrivalTime;
        
        currentTime += process.burstTime;
        totalWaitingTime += process.waitingTime;
    });

    const averageWaitingTime = totalWaitingTime / processes.length;
    
    // Update table with scheduling results
    const tableBody = document.querySelector('#processTable tbody');
    tableBody.innerHTML = '';
    processes.forEach(process => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>P${process.pid}</td>
            <td>${process.arrivalTime}</td>
            <td>${process.burstTime}</td>
            <td>${process.completionTime}</td>
            <td>${process.turnAroundTime}</td>
            <td>${process.waitingTime}</td>
        `;
        tableBody.appendChild(row); 
    }); 
    
    console.log("FCFS Scheduling:");
    console.log("Average Waiting Time:", averageWaitingTime);
}

function generateTable() {
    const numProcesses = parseInt(document.getElementById('numProcesses').value);
    const tableBody = document.querySelector('#processTable tbody');
    tableBody.innerHTML = '';

    for (let i = 1; i <= numProcesses; i++) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>P${i}</td>
            <td><input type="text" id="arrivalTime${i}" value="0"></td>
            <td><input type="text" id="burstTime${i}" value="1"></td>
            <td></td>
            <td></td>
            <td></td>
        `;
        tableBody.appendChild(row);
    }
}

function performScheduling() {
    const numProcesses = parseInt(document.getElementById('numProcesses').value);
    const processes = [];

    for (let i = 1; i <= numProcesses; i++) {
        const arrivalTime = parseInt(document.getElementById(`arrivalTime${i}`).value);
        const burstTime = parseInt(document.getElementById(`burstTime${i}`).value);
        processes.push(new Process(i, arrivalTime, burstTime));
    }

    fcfsScheduling(processes);
} 

   // Update Gantt chart
   document.getElementById('ganttChartBody').innerHTML = ganttChartHTML;
            
   console.log("FCFS Scheduling:");
   console.log("Average Waiting Time:", averageWaitingTime);
